
				</div>
				<script type="text/javascript" src="<?php echo $url; ?>content/js/jquery-3.2.1.slim.min.js"></script>
				<script type="text/javascript" src="<?php echo $url; ?>content/js/jquery-3.1.1.min.js"></script>
				<script type="text/javascript" src="<?php echo $url; ?>content/js/popper.min.js"></script>
				<script type="text/javascript" src="<?php echo $url; ?>content/js/bootstrap.min.js"></script>
				<script type="text/javascript" src="<?php echo $url; ?>content/js/jquery.mask.js"></script>
				<script type="text/javascript" src="<?php echo $url; ?>content/js/front.js"></script>
				<script type="text/javascript" src="<?php echo $url; ?>content/js/Init.js"></script>
				<script type="text/javascript" src="<?php echo $url; ?>content/js/Main.js"></script>
				<script type="text/javascript" src="<?php echo $url; ?>content/js/Chart.js"></script>
				<script type="text/javascript" src="<?php echo $url; ?>content/js/legend.js"></script>

			</div>
		</body> 
</html>