<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>404 Page Not Found</title>
	<?= link_tag('css/site.css') ?>
	<?= link_tag('css/bootstrap.min.css') ?>
</head>
<body>
	<div class="container-fluid text-center" style=' background-color: white;'>
		<br />
		<h1>Registro não encontrado</h1>
		<br />
		<a href="javascript:window.history.go(-1)">Voltar a página inicial</a>
		<br />
		<br />

	</div>
</body>
</html>