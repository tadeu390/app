
				</div>
				<script type="text/javascript" src="<?php echo $url; ?>js/jquery-3.2.1.slim.min.js"></script>
				<script type="text/javascript" src="<?php echo $url; ?>js/jquery-3.1.1.min.js"></script>
				<script type="text/javascript" src="<?php echo $url; ?>js/popper.min.js"></script>
				<script type="text/javascript" src="<?php echo $url; ?>js/bootstrap.min.js"></script>
				<script type="text/javascript" src="<?php echo $url; ?>js/jquery.mask.js"></script>
				<script type="text/javascript" src="<?php echo $url; ?>js/front.js"></script>
				<script type="text/javascript" src="<?php echo $url; ?>js/Init.js"></script>
				<script type="text/javascript" src="<?php echo $url; ?>js/Main.js"></script>
				<script type="text/javascript" src="<?php echo $url; ?>js/Chart.js"></script>
				<script type="text/javascript" src="<?php echo $url; ?>js/legend.js"></script>
	
				<div class="container-fluid text-center" style='background-color: rgba(0,0,0,.5); width: 100%;color: white; position: fixed;z-index:-1; bottom: 0px; right: 0px;padding: 15px;'>
					&copy;  <?php echo date("Y"); ?> - Advansoftware
				</div>	
			</div>
		</body> 
</html>